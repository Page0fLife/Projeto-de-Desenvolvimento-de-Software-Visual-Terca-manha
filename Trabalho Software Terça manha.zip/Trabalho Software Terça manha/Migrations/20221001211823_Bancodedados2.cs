﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace API_Site.Migrations
{
    public partial class Bancodedados2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Inventario_Itens_ItemIdItensId",
                table: "Inventario");

            migrationBuilder.DropForeignKey(
                name: "FK_Inventario_Usuario_emailUsuarioId",
                table: "Inventario");

            migrationBuilder.RenameColumn(
                name: "emailUsuarioId",
                table: "Inventario",
                newName: "UsuarioId");

            migrationBuilder.RenameColumn(
                name: "ItemIdItensId",
                table: "Inventario",
                newName: "ItensId");

            migrationBuilder.RenameIndex(
                name: "IX_Inventario_ItemIdItensId",
                table: "Inventario",
                newName: "IX_Inventario_ItensId");

            migrationBuilder.RenameIndex(
                name: "IX_Inventario_emailUsuarioId",
                table: "Inventario",
                newName: "IX_Inventario_UsuarioId");

            migrationBuilder.AddColumn<int>(
                name: "ItemId",
                table: "Inventario",
                type: "INTEGER",
                nullable: false,
                defaultValue: 0);

            migrationBuilder.AddColumn<string>(
                name: "email",
                table: "Inventario",
                type: "TEXT",
                nullable: false,
                defaultValue: "");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventario_Itens_ItensId",
                table: "Inventario",
                column: "ItensId",
                principalTable: "Itens",
                principalColumn: "ItensId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Inventario_Usuario_UsuarioId",
                table: "Inventario",
                column: "UsuarioId",
                principalTable: "Usuario",
                principalColumn: "UsuarioId",
                onDelete: ReferentialAction.Restrict);
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropForeignKey(
                name: "FK_Inventario_Itens_ItensId",
                table: "Inventario");

            migrationBuilder.DropForeignKey(
                name: "FK_Inventario_Usuario_UsuarioId",
                table: "Inventario");

            migrationBuilder.DropColumn(
                name: "ItemId",
                table: "Inventario");

            migrationBuilder.DropColumn(
                name: "email",
                table: "Inventario");

            migrationBuilder.RenameColumn(
                name: "UsuarioId",
                table: "Inventario",
                newName: "emailUsuarioId");

            migrationBuilder.RenameColumn(
                name: "ItensId",
                table: "Inventario",
                newName: "ItemIdItensId");

            migrationBuilder.RenameIndex(
                name: "IX_Inventario_UsuarioId",
                table: "Inventario",
                newName: "IX_Inventario_emailUsuarioId");

            migrationBuilder.RenameIndex(
                name: "IX_Inventario_ItensId",
                table: "Inventario",
                newName: "IX_Inventario_ItemIdItensId");

            migrationBuilder.AddForeignKey(
                name: "FK_Inventario_Itens_ItemIdItensId",
                table: "Inventario",
                column: "ItemIdItensId",
                principalTable: "Itens",
                principalColumn: "ItensId",
                onDelete: ReferentialAction.Restrict);

            migrationBuilder.AddForeignKey(
                name: "FK_Inventario_Usuario_emailUsuarioId",
                table: "Inventario",
                column: "emailUsuarioId",
                principalTable: "Usuario",
                principalColumn: "UsuarioId",
                onDelete: ReferentialAction.Restrict);
        }
    }
}
