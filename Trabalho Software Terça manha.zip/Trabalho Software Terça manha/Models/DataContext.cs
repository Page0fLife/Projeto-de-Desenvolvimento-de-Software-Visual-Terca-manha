
using Microsoft.EntityFrameworkCore;

namespace API.Models
{
    public class DataContext : DbContext
    {
        public DataContext(DbContextOptions<DataContext> options) 
            : base(options) { }

        public DbSet<Usuario> Usuario { get; set; }
        public DbSet<Itens> Itens { get; set; }
        public DbSet<Inventario> Inventario { get; set; }
    }
}