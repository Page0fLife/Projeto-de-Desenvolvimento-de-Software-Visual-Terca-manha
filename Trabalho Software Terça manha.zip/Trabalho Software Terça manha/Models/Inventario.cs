using System;
using System.ComponentModel.DataAnnotations;

namespace API.Models{
    public class Inventario{
        public int Id { get; set; }

        [Required(ErrorMessage = "O Id do item é obrigatório!")]
        public int ItemId { get; set; }
        public Itens itens { get; set; }
        
        [Required(ErrorMessage = "O email do usuário é obrigatório!")]
        public string email { get; set;}
        public Usuario usuario { get; set;}
    }
}