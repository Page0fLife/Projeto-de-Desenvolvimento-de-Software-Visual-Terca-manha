﻿using System;

namespace ListaExercicio
{
    class Program
    {
        static void Main(string[] args)
        {
            // Exe01.Renderizar();
            Exe02.Renderizar();
        }
    }
}
