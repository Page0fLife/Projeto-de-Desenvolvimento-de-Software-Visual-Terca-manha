# Projetos da disciplina de Desenvolvimento de Software Visual

## Repositório de todos os projetos da disciplina de Desenvolvimento Visual de Software de terça-feira de manhã.

### **Exercício para a aula do dia 30/08/2022**:
  - Criar um projeto WebAPI para a Folha de Pagamento;
  - Realizar todas as operações de CRUD para um funcionário;
  - Um funcionário deverá ter nome, cpf, data de nascimento e 
  criado em.

### **Exercício para a aula do dia 06/09/2022**:
  - Realizar todas as operações para criar um banco de dados dentro do projeto do trabalho;
  - Realizar ao menos a gravação de um objeto na base de dados;
  - Verificar os dados dentro de qualquer ferramenta de visualização do Sqlite.