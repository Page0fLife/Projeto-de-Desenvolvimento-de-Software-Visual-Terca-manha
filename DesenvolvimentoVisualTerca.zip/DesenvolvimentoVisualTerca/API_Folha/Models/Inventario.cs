using System;

namespace API.Models
{
    public class Inventario
    {
        public int Iditem { get; set; }
        public int Id { get; set; }
    }
}