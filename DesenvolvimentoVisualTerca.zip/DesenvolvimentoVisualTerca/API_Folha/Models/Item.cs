using System;
using System.ComponentModel.DataAnnotations;
//using API_Folha.Validations;

namespace API.Models
{
    //Data Annotations
    public class Item
    {
        
        public int Iditem { get; set; }

        public int Id { get; set; }

        [Required(ErrorMessage = "O campo nome é obrigatório!")]
        public string Nome { get; set; }


       
        
    }
}