using System.ComponentModel.DataAnnotations;
using System.Linq;
using API.Models;

namespace API_Folha.Validations
{
    public class IdEmUso : ValidationAttribute
    {
        // public CpfEmUso(string cpf) { }
        protected override ValidationResult IsValid(object value, ValidationContext validationContext)
        {
            int id = (int)value;

            DataContext context =
                (DataContext)validationContext.GetService(typeof(DataContext));

            Usuario usuario = context.Usuario.FirstOrDefault
                (f => f.Id.Equals(id));
                
            if (usuario == null)
            {
                //Caso de sucesso
                return ValidationResult.Success;
            }
            //Caso de erro
            return new ValidationResult("O ID do funcionário já está em uso!");
        }
    }
}