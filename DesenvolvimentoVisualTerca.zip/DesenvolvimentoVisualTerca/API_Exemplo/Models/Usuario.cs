namespace API.Models
{
    public class Usuario
    {
        public string Email { get; set; }
        public string Senha { get; set; }
    }
}