using System.Collections.Generic;
using System.Linq;
using API.Models;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers{
    [ApiController]
    [Route("api/item")]
    public class ItemController : ControllerBase{
        private readonly DataContext _context;
        public ItemController (DataContext context) => _context = context;
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody] Itens item){
            _context.Itens.Add(item);
            _context.SaveChanges();
            return Created("", item);
        }
        [HttpGet]
        [Route("listar")]
        public IActionResult Listar() => Ok(_context.Itens.ToList());
        [HttpPatch]
        [Route("alterar")]
        public IActionResult Alterar([FromBody] Itens item){
            try{
                _context.Itens.Update(item);
                _context.SaveChanges();
                return Ok(item);
            }catch{
                return NotFound();
            }
        }
        [HttpDelete]
        [Route("deletar/{id}")]
        public IActionResult Deletar([FromRoute] int id){
            Itens item = _context.Itens.Find(id);
            if(item != null){
                _context.Itens.Remove(item);
                _context.SaveChanges();
                return Ok();
            }
            return NotFound();
        }
    }
}