using System.Collections.Generic;
using System.Linq;
using API.Models;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers{
    [ApiController]
    [Route("api/inventario")]
    public class InventarioController : ControllerBase{
        private readonly DataContext _context;
        public InventarioController (DataContext context) => _context = context;
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody] Inventario inventario){
            return NotFound();
        }
        [HttpGet]
        [Route("checar")]
        public IActionResult Checar() => Ok(_context.Inventario.ToList());
        [HttpPatch]
        [Route("modificar")]
        public IActionResult Modificar([FromBody]Inventario inventario){
            try{
                _context.Inventario.Update(inventario);
                _context.SaveChanges();
                return Ok(inventario);
            }catch{
                return NotFound();
            }
        }
        [HttpDelete]
        [Route("deletar/{id}")]
        public IActionResult Deletar([FromHeader]int id){
            Inventario inventario = _context.Inventario.Find(id);
            if(inventario != null){
                _context.Inventario.Remove(inventario);
                _context.SaveChanges();
                return Ok();
            }
            return NotFound();
        }       
    }
}