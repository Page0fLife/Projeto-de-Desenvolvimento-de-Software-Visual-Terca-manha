using System.Collections.Generic;
using System.Linq;
using API.Models;
using Microsoft.AspNetCore.Mvc;

namespace API.Controllers{
    [ApiController]
    [Route("api/usuario")]
    public class UsuarioController : ControllerBase{
        private readonly DataContext _context;
        public UsuarioController (DataContext context) => _context = context;
        [HttpPost]
        [Route("cadastrar")]
        public IActionResult Cadastrar([FromBody] Usuario usuario){
            _context.Usuarios.Add(usuario);
            _context.SaveChanges();
            return Created("", usuario);
        }
        [HttpGet]
        [Route("listar")]
        public IActionResult Listar() => Ok(_context.Usuarios.ToList());

        [HttpPatch]
        [Route("alterar")]
        public IActionResult Alterar([FromBody] Usuario usuario){
            try{
                _context.Usuarios.Update(usuario);
                _context.SaveChanges();
                return Ok(usuario);
            }catch{
                return NotFound();
            }
        }
        [HttpDelete]
        [Route("deletar/{email}-{senha}")]
        public IActionResult Deletar([FromRoute] string email, string senha){
            Usuario usuario = _context.Usuarios.Find(email, senha);
            if(usuario != null){
                _context.Usuarios.Remove(usuario);
                _context.SaveChanges();
                return Ok();
            }
            return NotFound();
        }
    }
}