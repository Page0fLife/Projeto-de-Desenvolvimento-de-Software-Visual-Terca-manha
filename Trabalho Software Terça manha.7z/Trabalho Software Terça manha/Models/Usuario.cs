using System;
using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    //Data Annotations
    public class Usuario
    {
        public int Id { get; set; }

        [Required(ErrorMessage = "O campo nome é obrigatório!")]
        public string Nome { get; set; }

         [EmailAddress(
            ErrorMessage = "E-mail inválido!"
        )]
        public string Email { get; set; }

         [Required(ErrorMessage = "O campo senha é obrigatório!")]
         public string Senha { get; set;}
    }
}