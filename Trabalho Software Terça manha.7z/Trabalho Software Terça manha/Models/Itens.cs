using System;
using System.ComponentModel.DataAnnotations;

namespace API.Models
{
    //Data Annotations
    public class Itens{
        public int ItemId { get; set; }

        [Required(ErrorMessage = "O campo nome é obrigatório!")]
        public string Nome { get; set; }

        [Required(ErrorMessage = "O campo categoria é obrigatório!")]
        public string Categoria { get; set; }

        [Required(ErrorMessage = "O campo descrição é obrigatório!")]
        public string Descricao { get; set; }

        [Required(ErrorMessage = "O campo preço é obrigatório!")]
        public double Preco { get; set;}

        [Required(ErrorMessage = "O campo jogo é obrigatório!")]
        public string Jogo { get; set; }
    }
}