using System;
using System.ComponentModel.DataAnnotations;

namespace API.Models{
    public class Inventario{
        public int Id { get; set; }

        public string email { get; set;}

        public double preco { get; set;}
    }
}